package pl.nocnyplayer

import android.Manifest
import android.app.Activity
import android.content.ContentUris
import android.content.Context
import android.content.pm.PackageManager
import android.database.Cursor
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.media.app.NotificationCompat as MediaNotificationCompat
import androidx.media.session.MediaButtonReceiver
import android.support.v4.media.MediaMetadataCompat
import android.support.v4.media.session.MediaSessionCompat
import android.support.v4.media.session.PlaybackStateCompat
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import org.json.JSONArray
import org.json.JSONObject
import java.io.FileNotFoundException
import kotlin.math.abs

data class Track(val id: Long, val title: String, val artist: String, val uri: Uri, val duration: Long, val albumId: Long)

class MainActivity : Activity() {
    private val bg = Color.rgb(10, 12, 20)
    private val panel = Color.rgb(22, 26, 40)
    private val neon = Color.rgb(35, 145, 255) // neonowy niebieski
    private val white = Color.rgb(239, 244, 255)
    private val muted = Color.rgb(145, 157, 178)
    private val tracks = mutableListOf<Track>()
    private val favorites = mutableSetOf<Long>()
    private val playlists = linkedMapOf<String, MutableSet<Long>>()
    private var player: MediaPlayer? = null
    private var current = -1
    private var dragging = false
    private var shuffle = false
    private var repeatMode = 0 // 0 off, 1 all, 2 one
    private var equalizer: Equalizer? = null
    private var bassBoost: BassBoost? = null
    private var preamp = 1.0f
    private var balance = 0.0f
    private var visualStyle = 0
    private lateinit var visualizerView: AudioVisualizerView
    private var mediaSession: MediaSessionCompat? = null
    private lateinit var titleView: TextView
    private lateinit var artistView: TextView
    private lateinit var playButton: Button
    private lateinit var seek: SeekBar
    private lateinit var timeView: TextView
    private lateinit var list: LinearLayout
    private lateinit var status: TextView
    private lateinit var albumArt: ImageView
    private lateinit var favButton: Button
    private lateinit var shuffleButton: Button
    private lateinit var repeatButton: Button
    private lateinit var filter: Spinner
    private val handler = android.os.Handler(android.os.Looper.getMainLooper())
    private var filterMode = "Wszystkie"

    private val tick = object : Runnable {
        override fun run() {
            val p = player
            if (p != null) {
                if (::visualizerView.isInitialized) visualizerView.invalidate()
                if (p.isPlaying && !dragging) seek.progress = p.currentPosition
                timeView.text = "${format(p.currentPosition.toLong())}  /  ${format(p.duration.toLong())}"
            }
            handler.postDelayed(this, 400)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        loadSaved()
        buildUi()
        setupMediaSession()
        requestAudioPermission()
        handler.post(tick)
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(16), dp(18), dp(10))
            setBackgroundColor(bg)
        }
        setContentView(root)

        root.addView(TextView(this).apply {
            text = "ARIEL PLAYER"
            textSize = 24f; letterSpacing = .08f; setTextColor(neon)
            typeface = Typeface.create("sans-serif-black", Typeface.BOLD_ITALIC)
        })
        root.addView(TextView(this).apply {
            text = "MUZYKA • OFFLINE • TWÓJ RYTM"
            textSize = 10f; letterSpacing = .16f; setTextColor(muted)
            setPadding(0, dp(3), 0, dp(12))
        })

        val now = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            setPadding(dp(14), dp(14), dp(14), dp(14)); background = rounded(panel, dp(20))
        }
        root.addView(now, LinearLayout.LayoutParams(-1, dp(365)))

        albumArt = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            background = rounded(Color.rgb(16, 39, 74), dp(18))
            setImageResource(android.R.drawable.ic_media_play)
        }
        now.addView(albumArt, LinearLayout.LayoutParams(dp(112), dp(112)).apply { bottomMargin = dp(8) })

        visualizerView = AudioVisualizerView(this).apply { setStyle(0) }
        now.addView(visualizerView, LinearLayout.LayoutParams(-1, dp(54)).apply { bottomMargin = dp(5) })
        val visualModes = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        listOf("PS1", "WINAMP", "WMP").forEachIndexed { index, name ->
            visualModes.addView(smallControl(name) {
                visualStyle = index
                visualizerView.setStyle(index)
            }, LinearLayout.LayoutParams(0, dp(28), 1f).apply {
                leftMargin = dp(3); rightMargin = dp(3)
            })
        }
        now.addView(visualModes, LinearLayout.LayoutParams(-1, dp(30)))

        titleView = TextView(this).apply {
            text = "Wybierz swój utwór"; textSize = 19f; gravity = Gravity.CENTER
            setTextColor(white); typeface = Typeface.DEFAULT_BOLD; maxLines = 1
        }
        now.addView(titleView, LinearLayout.LayoutParams(-1, -2))
        artistView = TextView(this).apply {
            text = "Twoja muzyka, bez internetu"; textSize = 13f; gravity = Gravity.CENTER
            setTextColor(muted); setPadding(0, dp(4), 0, dp(7)); maxLines = 1
        }
        now.addView(artistView, LinearLayout.LayoutParams(-1, -2))

        seek = SeekBar(this).apply {
            progressTintList = android.content.res.ColorStateList.valueOf(neon)
            thumbTintList = android.content.res.ColorStateList.valueOf(neon)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, progress: Int, fromUser: Boolean) {}
                override fun onStartTrackingTouch(s: SeekBar?) { dragging = true }
                override fun onStopTrackingTouch(s: SeekBar?) { player?.seekTo(s?.progress ?: 0); dragging = false }
            })
        }
        now.addView(seek, LinearLayout.LayoutParams(-1, -2))
        timeView = TextView(this).apply { text = "00:00 / 00:00"; textSize = 10f; setTextColor(muted); gravity = Gravity.CENTER }
        now.addView(timeView, LinearLayout.LayoutParams(-1, -2))

        val controls = LinearLayout(this).apply { gravity = Gravity.CENTER; orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(8), 0, dp(3)) }
        now.addView(controls, LinearLayout.LayoutParams(-1, -2))
        controls.addView(control("⏮", 19) { previous() })
        playButton = control("▶", 25) { togglePlayback() }.apply { setTextColor(bg); background = rounded(neon, dp(50)) }
        controls.addView(playButton, LinearLayout.LayoutParams(dp(56), dp(48)).apply { leftMargin = dp(12); rightMargin = dp(12) })
        controls.addView(control("⏭", 19) { next() })
        favButton = control("♡", 18) { toggleFavorite() }
        controls.addView(favButton)

        val modes = LinearLayout(this).apply { gravity = Gravity.CENTER; orientation = LinearLayout.HORIZONTAL }
        now.addView(modes, LinearLayout.LayoutParams(-1, dp(40)))
        shuffleButton = smallControl("SHUFFLE") { shuffle = !shuffle; updateModeButtons() }
        repeatButton = smallControl("REPEAT: OFF") { repeatMode = (repeatMode + 1) % 3; updateModeButtons() }
        modes.addView(shuffleButton, LinearLayout.LayoutParams(0, dp(34), 1f).apply { rightMargin = dp(5) })
        modes.addView(repeatButton, LinearLayout.LayoutParams(0, dp(34), 1f).apply { leftMargin = dp(5) })

        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; setPadding(0, dp(10), 0, dp(5)) }
        root.addView(actions, LinearLayout.LayoutParams(-1, -2))
        actions.addView(smallControl("KOREKTOR") { showEqualizer() }, LinearLayout.LayoutParams(0, dp(40), 1f).apply { rightMargin = dp(4) })
        actions.addView(smallControl("MIKSER / PREAMP") { showMixer() }, LinearLayout.LayoutParams(0, dp(40), 1f).apply { leftMargin = dp(4); rightMargin = dp(4) })
        actions.addView(smallControl("LISTY") { showPlaylists() }, LinearLayout.LayoutParams(0, dp(40), 1f).apply { leftMargin = dp(4); rightMargin = dp(4) })
        actions.addView(smallControl("♥") { filterMode = "Ulubione"; renderTracks() }, LinearLayout.LayoutParams(0, dp(40), 1f).apply { leftMargin = dp(4) })

        val listHeader = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(10), 0, dp(5)) }
        listHeader.addView(TextView(this).apply { text = "BIBLIOTEKA"; textSize = 13f; letterSpacing = .08f; setTextColor(white); typeface = Typeface.DEFAULT_BOLD },
            LinearLayout.LayoutParams(0, -2, 1f))
        filter = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, listOf("Wszystkie", "Ulubione") + playlists.keys.toList())
            setSelection(0)
            onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
                override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
                override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) {
                    filterMode = parent?.getItemAtPosition(position)?.toString() ?: "Wszystkie"
                    renderTracks()
                }
            }
        }
        listHeader.addView(filter, LinearLayout.LayoutParams(dp(150), dp(42)))
        listHeader.addView(smallControl("↻") { loadTracks() }, LinearLayout.LayoutParams(dp(48), dp(38)))
        root.addView(listHeader)
        status = TextView(this).apply { text = "Szukam muzyki…"; textSize = 11f; setTextColor(muted); setPadding(dp(2), 0, 0, dp(5)) }
        root.addView(status)
        val scroll = ScrollView(this)
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        updateModeButtons()
    }

    private fun control(label: String, size: Int, action: () -> Unit) = Button(this).apply {
        text = label; textSize = size.toFloat(); setTextColor(white); background = rounded(panel, dp(50))
        setPadding(dp(4), 0, dp(4), 0); minWidth = dp(38)
        setOnClickListener { action() }
    }

    private fun smallControl(label: String, action: () -> Unit) = Button(this).apply {
        text = label; textSize = 10f; setTextColor(neon); background = rounded(panel, dp(12))
        setPadding(dp(4), 0, dp(4), 0); minWidth = 0
        setOnClickListener { action() }
    }

    private fun rounded(color: Int, radius: Int) = android.graphics.drawable.GradientDrawable().apply {
        setColor(color); cornerRadius = radius.toFloat()
    }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun requestAudioPermission() {
        val permissions = if (Build.VERSION.SDK_INT >= 33)
            arrayOf(Manifest.permission.READ_MEDIA_AUDIO, Manifest.permission.READ_MEDIA_IMAGES)
        else arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
        val needed = permissions.filter { Build.VERSION.SDK_INT < 23 || checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (needed.isNotEmpty()) requestPermissions(needed.toTypedArray(), 100) else loadTracks()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, results)
        if (requestCode == 100 && results.isNotEmpty() && results[0] == PackageManager.PERMISSION_GRANTED) loadTracks()
        else status.text = "Zezwól na dostęp do plików audio, aby znaleźć muzykę."
    }

    private fun loadTracks() {
        tracks.clear()
        val collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE, MediaStore.Audio.Media.ARTIST, MediaStore.Audio.Media.DURATION, MediaStore.Audio.Media.ALBUM_ID)
        try {
            contentResolver.query(collection, projection, "${MediaStore.Audio.Media.IS_MUSIC} != 0", null, "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC")?.use {
                val idCol = it.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
                val titleCol = it.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
                val artistCol = it.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
                val durationCol = it.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
                val albumCol = it.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM_ID)
                while (it.moveToNext()) {
                    val id = it.getLong(idCol)
                    tracks.add(Track(id, it.getString(titleCol) ?: "Nieznany utwór",
                        (it.getString(artistCol) ?: "").takeIf { a -> a.isNotBlank() && a != "<unknown>" } ?: "Nieznany wykonawca",
                        ContentUris.withAppendedId(collection, id), it.getLong(durationCol), it.getLong(albumCol)))
                }
            }
        } catch (_: Exception) {}
        renderTracks()
    }

    private fun renderTracks() {
        if (!::list.isInitialized) return
        list.removeAllViews()
        val visible = when {
            filterMode == "Ulubione" -> tracks.filter { favorites.contains(it.id) }
            playlists.containsKey(filterMode) -> tracks.filter { playlists[filterMode]?.contains(it.id) == true }
            else -> tracks
        }
        status.text = if (visible.isEmpty()) "Brak utworów w tym widoku. Dodaj MP3 lub wybierz inną listę." else "${visible.size} utworów • offline"
        visible.forEachIndexed { index, track ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(10), dp(10), dp(10), dp(10)); background = rounded(panel, dp(14))
                setOnClickListener { play(tracks.indexOfFirst { it.id == track.id }) }
                setOnLongClickListener { addTrackToPlaylist(track); true }
            }
            val art = ImageView(this).apply {
                scaleType = ImageView.ScaleType.CENTER_CROP
                setImageBitmap(getAlbumArt(track.albumId))
                background = rounded(Color.rgb(16, 39, 74), dp(8))
            }
            row.addView(art, LinearLayout.LayoutParams(dp(46), dp(46)).apply { rightMargin = dp(10) })
            val labels = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            labels.addView(TextView(this).apply { text = track.title; textSize = 13f; setTextColor(white); typeface = Typeface.DEFAULT_BOLD; maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END })
            labels.addView(TextView(this).apply { text = "${track.artist} • ${format(track.duration)}"; textSize = 10f; setTextColor(muted); maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END })
            row.addView(labels, LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(TextView(this).apply { text = if (favorites.contains(track.id)) "♥" else "♫"; textSize = 17f; setTextColor(neon); gravity = Gravity.CENTER }, LinearLayout.LayoutParams(dp(28), -2))
            list.addView(row, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(6) })
        }
        updateFavoriteButton()
        updateFilterSpinner()
    }

    private fun getAlbumArt(albumId: Long): android.graphics.Bitmap? {
        return try {
            val uri = Uri.parse("content://media/external/audio/albumart/$albumId")
            contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) }
        } catch (_: Exception) { null }
    }

    private fun play(index: Int) {
        if (index !in tracks.indices) return
        try {
            player?.release()
            equalizer?.release(); equalizer = null
            bassBoost?.release(); bassBoost = null
            current = index
            val track = tracks[index]
            player = MediaPlayer().apply {
                setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
                setDataSource(this@MainActivity, track.uri)
                setOnPreparedListener { mp ->
                    applyMixer()
                    mp.start()
                    titleView.text = track.title; artistView.text = track.artist
                    playButton.text = "Ⅱ"; seek.max = mp.duration; seek.progress = 0
                    albumArt.setImageBitmap(getAlbumArt(track.albumId))
                    if (albumArt.drawable == null) albumArt.setImageResource(android.R.drawable.ic_media_play)
                    setupEffects(mp.audioSessionId)
                    updateFavoriteButton()
                    updateMediaSession(track)
                    updateNotification(track)
                }
                setOnCompletionListener {
                    when (repeatMode) {
                        2 -> { it.seekTo(0); it.start() }
                        else -> next()
                    }
                }
                prepareAsync()
            }
            titleView.text = track.title; artistView.text = "Ładowanie utworu…"
            updateMediaSession(track)
        } catch (_: Exception) { status.text = "Nie udało się odtworzyć pliku." }
    }

    private fun togglePlayback() {
        val p = player
        if (p == null) { if (tracks.isNotEmpty()) play(0) else loadTracks(); return }
        if (p.isPlaying) { p.pause(); playButton.text = "▶"; updatePlaybackState(false) }
        else { p.start(); playButton.text = "Ⅱ"; updatePlaybackState(true) }
    }

    private fun next() {
        if (tracks.isEmpty()) return
        val nextIndex = if (shuffle && tracks.size > 1) {
            var candidate: Int
            do { candidate = tracks.indices.random() } while (candidate == current)
            candidate
        } else if (current + 1 >= tracks.size && repeatMode == 0) {
            player?.pause(); playButton.text = "▶"; return
        } else (current + 1) % tracks.size
        play(nextIndex)
    }
    private fun previous() {
        if (tracks.isEmpty()) return
        val p = player
        if (p != null && p.currentPosition > 3000) p.seekTo(0)
        else play(if (current <= 0) tracks.lastIndex else current - 1)
    }

    private fun toggleFavorite() {
        if (current !in tracks.indices) return
        val id = tracks[current].id
        if (!favorites.add(id)) favorites.remove(id)
        saveSaved(); updateFavoriteButton(); renderTracks()
    }
    private fun updateFavoriteButton() {
        if (::favButton.isInitialized) {
            favButton.text = if (current in tracks.indices && favorites.contains(tracks[current].id)) "♥" else "♡"
            favButton.setTextColor(if (favButton.text == "♥") neon else white)
        }
    }
    private fun updateModeButtons() {
        if (::shuffleButton.isInitialized) shuffleButton.text = if (shuffle) "SHUFFLE: ON" else "SHUFFLE"
        if (::repeatButton.isInitialized) repeatButton.text = when (repeatMode) { 1 -> "REPEAT: ALL"; 2 -> "REPEAT: ONE"; else -> "REPEAT: OFF" }
    }

    private fun showEqualizer() {
        val p = player
        if (p == null) { Toast.makeText(this, "Najpierw włącz utwór.", Toast.LENGTH_SHORT).show(); return }
        if (equalizer == null) setupEffects(p.audioSessionId)
        val eq = equalizer ?: return
        val bass = bassBoost ?: return
        val layout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), dp(8)) }
        val bassSeek = SeekBar(this).apply {
            max = 1000; progress = bass.roundedStrength.toInt().coerceIn(0, 1000)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, value: Int, fromUser: Boolean) { if (fromUser) bass.setStrength(value.toShort()) }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        layout.addView(TextView(this).apply { text = "BAS"; setTextColor(neon) })
        layout.addView(bassSeek)
        val range = eq.bandLevelRange
        for (band in 0 until eq.numberOfBands) {
            val label = TextView(this).apply { text = "${eq.getCenterFreq(band.toShort()) / 1000} Hz"; setTextColor(white) }
            layout.addView(label)
            val seekbar = SeekBar(this).apply {
                max = (range[1] - range[0]).toInt()
                progress = (eq.getBandLevel(band.toShort()) - range[0]).toInt()
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(s: SeekBar?, value: Int, fromUser: Boolean) {
                        if (fromUser) eq.setBandLevel(band.toShort(), (value + range[0]).toShort())
                    }
                    override fun onStartTrackingTouch(s: SeekBar?) {}
                    override fun onStopTrackingTouch(s: SeekBar?) {}
                })
            }
            layout.addView(seekbar)
        }
        AlertDialogCompat.show(this, "Equalizer i bas", layout)
    }

    private fun showMixer() {
        val p = player
        if (p == null) {
            Toast.makeText(this, "Najpierw uruchom utwór — wtedy mikser może zadziałać.", Toast.LENGTH_SHORT).show()
            return
        }
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(10), dp(20), dp(8))
        }
        layout.addView(TextView(this).apply { text = "PRZEDWZMACNIACZ  •  ${(preamp * 100).toInt()}%"; setTextColor(neon) })
        val preampSeek = SeekBar(this).apply {
            max = 200; progress = (preamp * 100).toInt().coerceIn(0, 200)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, value: Int, fromUser: Boolean) {
                    if (fromUser) { preamp = value / 100f; applyMixer() }
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        layout.addView(preampSeek)
        layout.addView(TextView(this).apply { text = "BALANS L / R  •  ${balanceLabel()}"; setTextColor(neon) })
        val balanceSeek = SeekBar(this).apply {
            max = 200; progress = ((balance + 1f) * 100).toInt()
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, value: Int, fromUser: Boolean) {
                    if (fromUser) { balance = value / 100f - 1f; applyMixer() }
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        layout.addView(balanceSeek)
        layout.addView(TextView(this).apply {
            text = "Przedwzmacniacz zmienia głośność sygnału aplikacji; balans ustawia proporcje lewego i prawego kanału."
            textSize = 12f; setTextColor(muted); setPadding(0, dp(8), 0, 0)
        })
        AlertDialogCompat.show(this, "Mikser audio", layout)
    }

    private fun balanceLabel(): String = when {
        balance < -0.05f -> "LEWO"
        balance > 0.05f -> "PRAWO"
        else -> "ŚRODEK"
    }

    private fun applyMixer() {
        val p = player ?: return
        val left = (preamp * (if (balance > 0f) 1f - balance else 1f)).coerceIn(0f, 1f)
        val right = (preamp * (if (balance < 0f) 1f + balance else 1f)).coerceIn(0f, 1f)
        p.setVolume(left, right)
    }

    private fun setupEffects(sessionId: Int) {
        try {
            equalizer?.release(); bassBoost?.release()
            equalizer = Equalizer(0, sessionId).apply { enabled = true }
            bassBoost = BassBoost(0, sessionId).apply { enabled = true }
        } catch (_: Exception) { equalizer = null; bassBoost = null }
    }

    private fun showPlaylists() {
        val options = arrayOf("Utwórz nową playlistę", "Dodaj aktualny utwór do playlisty")
        android.app.AlertDialog.Builder(this).setTitle("Playlisty")
            .setItems(options) { _, which ->
                if (which == 0) {
                    val input = EditText(this).apply { hint = "Nazwa playlisty" }
                    android.app.AlertDialog.Builder(this).setTitle("Nowa playlista").setView(input)
                        .setPositiveButton("Utwórz") { _, _ ->
                            val name = input.text.toString().trim()
                            if (name.isNotEmpty() && name != "Wszystkie" && name != "Ulubione") {
                                playlists.putIfAbsent(name, mutableSetOf()); saveSaved(); updateFilterSpinner()
                                Toast.makeText(this, "Utworzono: $name", Toast.LENGTH_SHORT).show()
                            }
                        }.setNegativeButton("Anuluj", null).show()
                } else if (current in tracks.indices) addTrackToPlaylist(tracks[current])
                else Toast.makeText(this, "Najpierw odtwórz utwór.", Toast.LENGTH_SHORT).show()
            }.setNegativeButton("Zamknij", null).show()
    }

    private fun addTrackToPlaylist(track: Track) {
        if (playlists.isEmpty()) { showPlaylists(); return }
        val names = playlists.keys.toTypedArray()
        android.app.AlertDialog.Builder(this).setTitle("Dodaj do playlisty")
            .setItems(names) { _, which ->
                playlists[names[which]]?.add(track.id); saveSaved()
                Toast.makeText(this, "Dodano do ${names[which]}", Toast.LENGTH_SHORT).show()
                renderTracks()
            }.show()
    }

    private fun updateFilterSpinner() {
        if (!::filter.isInitialized) return
        val values = listOf("Wszystkie", "Ulubione") + playlists.keys.toList()
        val old = filterMode
        filter.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, values)
        val idx = values.indexOf(old).coerceAtLeast(0)
        filter.setSelection(idx, false)
    }

    private fun saveSaved() {
        val prefs = getSharedPreferences("ariel_player", Context.MODE_PRIVATE)
        prefs.edit().putString("favorites", JSONArray(favorites.toList()).toString())
            .putString("playlists", JSONObject().apply {
                playlists.forEach { (name, ids) -> put(name, JSONArray(ids.toList())) }
            }.toString()).apply()
    }
    private fun loadSaved() {
        val prefs = getSharedPreferences("ariel_player", Context.MODE_PRIVATE)
        try {
            val arr = JSONArray(prefs.getString("favorites", "[]"))
            for (i in 0 until arr.length()) favorites.add(arr.getLong(i))
            val obj = JSONObject(prefs.getString("playlists", "{}"))
            val keys = obj.keys()
            while (keys.hasNext()) {
                val key = keys.next(); val arrIds = obj.getJSONArray(key); val ids = mutableSetOf<Long>()
                for (i in 0 until arrIds.length()) ids.add(arrIds.getLong(i))
                playlists[key] = ids
            }
        } catch (_: Exception) {}
    }

    private fun setupMediaSession() {
        mediaSession = MediaSessionCompat(this, "NocnyPlayer").apply {
            setCallback(object : MediaSessionCompat.Callback() {
                override fun onPlay() { runOnUiThread { togglePlayback() } }
                override fun onPause() { runOnUiThread { togglePlayback() } }
                override fun onSkipToNext() { runOnUiThread { next() } }
                override fun onSkipToPrevious() { runOnUiThread { previous() } }
                override fun onSeekTo(pos: Long) { runOnUiThread { player?.seekTo(pos.toInt()) } }
            })
            isActive = true
            setFlags(MediaSessionCompat.FLAG_HANDLES_MEDIA_BUTTONS or MediaSessionCompat.FLAG_HANDLES_TRANSPORT_CONTROLS)
        }
    }

    private fun updateMediaSession(track: Track) {
        val session = mediaSession ?: return
        session.setMetadata(MediaMetadataCompat.Builder()
            .putString(MediaMetadataCompat.METADATA_KEY_TITLE, track.title)
            .putString(MediaMetadataCompat.METADATA_KEY_ARTIST, track.artist)
            .putLong(MediaMetadataCompat.METADATA_KEY_DURATION, track.duration)
            .build())
        updatePlaybackState(player?.isPlaying == true)
    }

    private fun updatePlaybackState(playing: Boolean) {
        mediaSession?.setPlaybackState(PlaybackStateCompat.Builder()
            .setActions(PlaybackStateCompat.ACTION_PLAY or PlaybackStateCompat.ACTION_PAUSE or PlaybackStateCompat.ACTION_PLAY_PAUSE or PlaybackStateCompat.ACTION_SKIP_TO_NEXT or PlaybackStateCompat.ACTION_SKIP_TO_PREVIOUS or PlaybackStateCompat.ACTION_SEEK_TO)
            .setState(if (playing) PlaybackStateCompat.STATE_PLAYING else PlaybackStateCompat.STATE_PAUSED, player?.currentPosition?.toLong() ?: 0L, if (playing) 1f else 0f)
            .build())
        val track = tracks.getOrNull(current)
        if (track != null) updateNotification(track)
    }

    private fun updateNotification(track: Track) {
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) manager.createNotificationChannel(NotificationChannel("nocny_music", "Odtwarzanie muzyki", NotificationManager.IMPORTANCE_LOW))
        val openIntent = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)
        val notification = NotificationCompat.Builder(this, "nocny_music")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle(track.title)
            .setContentText(track.artist)
            .setContentIntent(openIntent)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setOngoing(player?.isPlaying == true)
            .addAction(android.R.drawable.ic_media_previous, "Poprzedni", actionPending(1))
            .addAction(if (player?.isPlaying == true) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play,
                if (player?.isPlaying == true) "Pauza" else "Odtwórz", actionPending(2))
            .addAction(android.R.drawable.ic_media_next, "Następny", actionPending(3))
            .build()
        manager.notify(11, notification)
    }

    private fun actionPending(which: Int): PendingIntent {
        val intent = Intent(this, MediaActionReceiver::class.java).putExtra("action", which)
        return PendingIntent.getBroadcast(this, which, intent, PendingIntent.FLAG_UPDATE_CURRENT or if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)
    }

    private fun format(ms: Long): String {
        val total = (ms.coerceAtLeast(0) / 1000).toInt()
        return "%02d:%02d".format(total / 60, total % 60)
    }

    override fun onDestroy() {
        handler.removeCallbacks(tick)
        player?.release(); player = null
        equalizer?.release(); bassBoost?.release()
        mediaSession?.isActive = false; mediaSession?.release()
        super.onDestroy()
    }
}

private class AudioVisualizerView(context: Context) : View(context) {
    private val paint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
    private var style = 0
    private var phase = 0f
    private val blue = Color.rgb(35, 145, 255)
    private val cyan = Color.rgb(110, 205, 255)
    fun setStyle(value: Int) { style = value; invalidate() }
    private fun wave(x: Float): Float = kotlin.math.sin(x.toDouble()).toFloat()

    override fun onDraw(canvas: android.graphics.Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat(); val h = height.toFloat()
        if (w <= 0f || h <= 0f) return
        phase += .17f
        paint.style = android.graphics.Paint.Style.FILL
        paint.color = Color.rgb(8, 16, 32)
        canvas.drawRoundRect(0f, 0f, w, h, 12f, 12f, paint)
        when (style) {
            0 -> { // retro PlayStation 1: blue wireframe horizon
                paint.style = android.graphics.Paint.Style.STROKE
                paint.strokeWidth = 1.2f; paint.color = blue
                val horizon = h * .55f
                for (i in 0..8) {
                    val y = horizon + i * i * h / 100f
                    canvas.drawLine(0f, y, w, y, paint)
                }
                for (i in -8..8) {
                    val x = w / 2f + i * w / 9f
                    canvas.drawLine(w / 2f, horizon, x + wave(phase) * 4f, h, paint)
                }
                paint.color = cyan; paint.strokeWidth = 2f
                val path = android.graphics.Path()
                for (x in 0..60) {
                    val px = x * w / 60f
                    val py = h * .42f + wave(x * .34f + phase) * h * .13f
                    if (x == 0) path.moveTo(px, py) else path.lineTo(px, py)
                }
                canvas.drawPath(path, paint)
            }
            1 -> { // Winamp-style bars
                paint.style = android.graphics.Paint.Style.FILL
                val count = 36; val gap = w / (count * 1.6f); val barW = gap * .72f
                for (i in 0 until count) {
                    val bh = (0.18f + (abs(wave(i * .63f + phase)) * .8f)) * h
                    val x = i * gap * 1.6f
                    paint.color = if (i % 3 == 0) cyan else blue
                    canvas.drawRoundRect(x, h - bh, x + barW, h, 2f, 2f, paint)
                }
            }
            else -> { // Windows Media Player-inspired orb / waveform
                paint.style = android.graphics.Paint.Style.STROKE
                paint.strokeWidth = 1.5f
                val cx = w / 2f; val cy = h / 2f
                for (r in 7..24 step 5) {
                    paint.color = if (r % 2 == 0) blue else cyan
                    canvas.drawCircle(cx, cy, r.toFloat() + wave(phase) * 3f, paint)
                }
                paint.color = cyan; paint.strokeWidth = 2f
                val path = android.graphics.Path()
                for (x in 0..80) {
                    val px = x * w / 80f
                    val py = cy + wave(x * .24f + phase) * h * .25f * abs(wave(x * .05f + phase))
                    if (x == 0) path.moveTo(px, py) else path.lineTo(px, py)
                }
                canvas.drawPath(path, paint)
            }
        }
    }
}

private object AlertDialogCompat {
    fun show(context: Context, title: String, view: View) {
        android.app.AlertDialog.Builder(context).setTitle(title).setView(view)
            .setPositiveButton("Gotowe", null).show()
    }
}
