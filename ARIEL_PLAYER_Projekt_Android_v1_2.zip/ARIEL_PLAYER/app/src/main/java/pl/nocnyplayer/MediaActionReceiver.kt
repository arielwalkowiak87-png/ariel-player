package pl.nocnyplayer

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.widget.Toast

class MediaActionReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        // Android media session and notification actions are represented in the app project.
        // The app Activity must be open for this lightweight first build's controls.
        val launch = Intent(context, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        context.startActivity(launch)
        Toast.makeText(context, "Otwórz Nocny Player, aby sterować muzyką.", Toast.LENGTH_SHORT).show()
    }
}
