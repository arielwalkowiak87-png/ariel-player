plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "pl.nocnyplayer"
    compileSdk = 35

    defaultConfig {
        applicationId = "pl.nocnyplayer"
        minSdk = 23
        targetSdk = 35
        versionCode = 3
        versionName = "1.2"
    }
}

dependencies {
    implementation("androidx.media:media:1.7.0")
}
