# ARIEL PLAYER 1.2 — projekt Android

Ciemny, niebieski odtwarzacz lokalnych plików audio. Styl nagłówka inspirowany gamingową typografią PlayStation (bez dołączania oryginalnego kroju pisma). Ikona launchera ma półprzezroczyste, granatowe tło i niebieskie akcenty.

## Funkcje w projekcie
- lokalna biblioteka audio i okładki albumów,
- odtwarzanie, pauza, poprzedni/następny, pasek postępu,
- ulubione, własne playlisty, shuffle i repeat,
- korektor / equalizer systemowy oraz wzmocnienie basu (zależne od obsługi telefonu),
- panel miksera z poziomem przedwzmacniacza aplikacji i balansem lewy/prawy kanał,
- trzy animowane wizualizacje: retro siatka PS1, słupki w stylu Winampa i fala/orb inspirowana Windows Media Player,
- sesja multimedialna i powiadomienie z przyciskami sterowania.

## Ważne ograniczenia
To projekt źródłowy — **nie jest skompilowany ani przetestowany na urządzeniu**. Wizualizacje są animacjami stylizowanymi, nie odtwarzają rzeczywistego widma częstotliwości. Androidowy `MediaPlayer.setVolume()` ogranicza głośność do zakresu 0–100%, więc suwak przedwzmacniacza reguluje poziom aplikacji, a nie gwarantuje fizycznego wzmocnienia ponad maksimum. Efekty korektora/basu zależą od urządzenia. Odtwarzanie w tle i sterowanie z ekranu blokady wymagają dalszego testowania i dopracowania usługi odtwarzania.

## Budowanie APK
1. Zainstaluj Android Studio oraz JDK 17.
2. Rozpakuj ZIP i otwórz folder `ARIEL_PLAYER` (folder zawierający `settings.gradle.kts`) w Android Studio.
3. Zsynchronizuj Gradle; zainstaluj Android SDK Platform 35, jeśli program o to poprosi.
4. Wybierz **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. Po kompilacji użyj przycisku **locate**. APK debug zwykle znajduje się w `app/build/outputs/apk/debug/app-debug.apk`.
6. Przenieś APK na telefon, zainstaluj i przyznaj dostęp do muzyki.

